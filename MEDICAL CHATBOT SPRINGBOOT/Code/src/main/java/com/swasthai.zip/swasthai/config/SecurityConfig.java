package com.swasthai.config;

import com.swasthai.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UserService userService;

    public SecurityConfig(UserService userService) {
        this.userService = userService;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                //
                // FIX 1: Added your public pages (/home, /features) to the permitAll list.
                //
                .requestMatchers(
                    "/css/**", "/js/**", "/images/**", 
                    "/", "/home", "/features",  // <-- ADDED PUBLIC PAGES
                    "/login", "/register"
                ).permitAll()
                //
                // All other requests (like /assistant) will require login
                //
                .anyRequest().authenticated() 
            )
            .formLogin(form -> form
                .loginPage("/login") 
                //
                // FIX 2: Changed the success URL to /assistant, which exists in your WebController.
                //
                .defaultSuccessUrl("/assistant", true) // <-- CHANGED FROM /dashboard
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            );
        
        return http.build();
    }
}