package com.swasthai.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swasthai.model.User;
import com.swasthai.model.dto.ChatRequest;
import com.swasthai.session.ChatState;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.chat.prompt.SystemPromptTemplate;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service
public class AiChatService {

    private final ChatClient chatClient; // New client for 1.1.0
    private final ObjectMapper objectMapper;
    private final ChatState chatState;

    public AiChatService(ChatClient.Builder chatClientBuilder, ObjectMapper objectMapper, ChatState chatState) {
        this.chatClient = chatClientBuilder.build();
        this.objectMapper = objectMapper;
        this.chatState = chatState;
    }

    public String handleChat(ChatRequest request, ChatState chatState, User user) {
        String userInput = request.message();
        String userProfile = getUserProfileString(user);

        try {
            if (request.isPredictionStart()) {
                chatState.resetChat();
                chatState.setStage("PREDICTION_STARTED");
                chatState.getSymptomData().put("initial", userInput);
            }

            String aiResponse = "";
            String stage = chatState.getStage();

            if ("PREDICTION_STARTED".equals(stage)) {
                String promptString = String.format(
                    "SYSTEM PERSONA: You are a medical data gathering AI. A user has reported these symptoms: \"%s\". " +
                    "Generate exactly 3 concise follow-up questions to clarify the condition. " +
                    "Your output MUST be a JSON array of strings, like [\"question 1\", \"question 2\", \"question 3\"]. Do not output any other text.",
                    chatState.getSymptomData().get("initial")
                );

                // New 1.1.0 chat client syntax
                String responseText = chatClient.prompt()
                    .user(promptString)
                    .call()
                    .content();
                
                responseText = responseText.replaceAll("(?s).*(\\[.*\\]).*", "$1"); 

                List<String> questions = objectMapper.readValue(responseText, new TypeReference<List<String>>() {});
                chatState.setFollowUpQuestions(questions);
                chatState.setStage("AWAITING_ANSWER_1");
                aiResponse = questions.get(0);
                
            } else if ("AWAITING_ANSWER_1".equals(stage)) {
                chatState.getSymptomData().put("answer1", userInput);
                chatState.setStage("AWAITING_ANSWER_2");
                aiResponse = chatState.getFollowUpQuestions().get(1);

            } else if ("AWAITING_ANSWER_2".equals(stage)) {
                chatState.getSymptomData().put("answer2", userInput);
                chatState.setStage("AWAITING_ANSWER_3");
                aiResponse = chatState.getFollowUpQuestions().get(2);

            } else if ("AWAITING_ANSWER_3".equals(stage)) {
                chatState.getSymptomData().put("answer3", userInput);
                
                String fullContext = String.format(
                    "Initial Symptoms: %s. Answers: 1. %s, 2. %s, 3. %s",
                    chatState.getSymptomData().get("initial"),
                    chatState.getSymptomData().get("answer1"),
                    chatState.getSymptomData().get("answer2"),
                    chatState.getSymptomData().get("answer3")
                );

                String systemPrompt = """
                    SYSTEM PERSONA: You are SwasthAI, a virtual first doctor.
                    YOUR TASK: Based on all user data, generate a structured medical report with these exact markdown headings:
                    **Disclaimer:** (Warn that you are an AI and not a substitute for a real doctor.)
                    **Possible Illness(es):** (List 1-2 likely conditions.)
                    **Recommended Generic Medicines:** (Suggest over-the-counter medicines like Paracetamol with dosage.)
                    **Lifestyle and Home Care:** (Provide a bulleted list of advice.)
                    **When to See a Doctor:** (List critical symptoms that require immediate medical attention.)
                    """;
                String userPrompt = String.format(
                    "USER DATA: Profile: %s. Full Symptom Report: %s.",
                    userProfile, fullContext);

                aiResponse = chatClient.prompt()
                    .system(systemPrompt)
                    .user(userPrompt)
                    .call()
                    .content();

                chatState.setLastPredictionResult(aiResponse);
                chatState.setLastAnalysisResult(null);
                chatState.resetChat();

            } else { // GENERAL chat stage
                String prompt = String.format(
                    "You are SwasthAI, a helpful medical assistant. A user with profile (%s) asks: '%s'. Answer informatively.",
                    userProfile, userInput
                );
                aiResponse = chatClient.prompt()
                    .user(prompt)
                    .call()
                    .content();
            }
            return aiResponse;
        } catch (Exception e) {
            e.printStackTrace();
            chatState.resetChat();
            return "An error occurred. Please try again.";
        }
    }

    public String getUserProfileString(User user) {
        return String.format(
            "Age: %s, Allergies: %s, Medical History: %s",
            user.getAge() != null ? user.getAge() : "Not provided",
            user.getAllergies() != null ? user.getAllergies() : "Not provided",
            user.getMedicalHistory() != null ? user.getMedicalHistory() : "Not provided"
        );
    }
}